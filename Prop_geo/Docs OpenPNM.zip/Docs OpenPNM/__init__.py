r"""
Collection of new functions by Cesar Timana
=========================================================
from ._doctxt import *   #if is a .py document
from . import misc  # if it is a file

"""

from ._funcs import *
