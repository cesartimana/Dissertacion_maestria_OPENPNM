#Modified by Cesar

import numpy as np
import math as m

__all__ = [
    "geo_props_eq_pores",
    "Gcorr_isos",
    "half_ang_isos",
    "Gcorr_beta_throats",
]


def geo_props_eq_pores(network):

    r"""
    Add the properties 'pore.length', 'pore.cross_sectional_area', 'pore.shape_factor' and  'pore.half_cont_angle' to the network.
    Assume a triangular tube (equilateral triangle).
    pore.surface_area ignores throat areas.
    pore.prism_surface_area is the area used in calculus minus throat areas


    """

    V_p = network['pore.volume']
    S_p = network['pore.surface_area']
    A_t = network['throat.cross_sectional_area']
    t_conns = network['throat.conns']

        #Adding areas: solid-fluid + throat areas per pore
    Np = len(V_p)
    Nt = len(A_t)

    pore_throat =  np.tile(np.arange(Np),(Nt,1)) #matrix Nt x Np. Each row have all pore numbers
    neigh1 = np.tile(np.array(t_conns)[:,0], (Np,1)).T #matrix Nt x Np.
    neigh2  = np.tile(np.array(t_conns)[:,1], (Np,1)).T #matrix Nt x Np.
    area_t_per_p =  np.sum(np.tile(A_t, (Np,1)).T * ((pore_throat == neigh1) |  (pore_throat == neigh2)), axis=0)
    As_p = S_p + area_t_per_p

    #Doing geometry
    G_max = 0.04811252243 #G for an equilateral triangle with 10 decimals

    As_min = 3**1.5*2**(1/3)*np.power(V_p, 2/3)

    As_used = np.fmax(As_p, As_min*1.0001) #To not have problems calculating parameters

    p = - 2 * As_used / 3**0.5
    q = 8 * V_p

    a_p = 2/3**0.5*np.power(-p, 0.5)*np.cos(1/3*np.arccos(3*q*3**0.5/2/p/np.power(-p, 0.5))-2*m.pi*1/3)
    A_p = np.power(a_p,2)*3**0.5/4
    h_p = V_p/A_p

    network['pore.length'] = h_p
    network['pore.cross_sectional_area'] = A_p
    network['pore.prism_surface_area'] = As_used - area_t_per_p
    network['pore.shape_factor'] = np.ones(Np) * G_max
    network['pore.half_cont_angle'] = np.ones((Np,3))*m.pi/6

    return


def Gcorr_isos(G_porespy, voxels, prob = 0.5, min_vox = 30):
    r"""
    Calculates the corrected shape factor G from G calculated by porespy, considering isosceles triangle

    prob: chance to use an isosceles triangle with different angle >= pi/3 (beta>=pi/6). Can be an array.
    Must be between 0 and 1
    min_vox: Minimum number of voxels to correct. If less, G = Gmax
    voxels +0.0001 to avoid problems dividing
    """
    G_max = 0.04811252243 #G for an equilateral triangle with 10 decimals
    t_bool = np.squeeze(np.random.rand(len(G_porespy),1)) < prob
    v_bool = voxels >= min_vox
    c = ((0.23913/np.log10(np.log10(voxels+0.0001)) + 0.79507) * t_bool  + (0.21057/np.log10(np.log10(voxels+0.0001)) + 0.82264) * ~t_bool)*v_bool
    G = np.min([0.5 * voxels**(c-1) * G_porespy**c, np.ones_like(G_porespy)*G_max], axis = 0)* v_bool + G_max * ~v_bool

    return G

def half_ang_isos(G, prob = 0.5):
    r"""
    Calculates the half angles considering isosceles triangle

    prob: chance to use an isosceles triangle with different angle >= pi/3 (beta>=pi/6). Can be an array.
    Must be between 0 and 1
    """
    t_bool = np.squeeze(np.random.rand(len(G),1)) < prob
    c = np.arccos(-12*3**0.5*G)/3+ t_bool * 4*m.pi/3
    beta2 = np.arctan(2/3**0.5*np.cos( c ))
    beta = np.sort( np.concatenate(([beta2], [beta2], [m.pi/2-beta2*2])).T , 1)

    return beta

def Gcorr_beta_throats(network, prob  = 0.5, min_vox = 30):

    r"""
    Add the properties 'throat.shape_factor' and  'throat.half_cont_angle' to the network,
    previous correction of the perimeter data.
    Correct the property 'throat.perimeter'
    Correct the property 'throat.inscribed_diameter', such that values aren't higher than the equivalent diameter

    prob: chance to use an isosceles triangle with different angle >= pi/3 (beta>=pi/6). Can be an array.
    Must be between 0 and 1
    """

    A_t = network['throat.cross_sectional_area']
    P_t = network['throat.perimeter']
    v_t = network['throat.voxels']
    G_t = A_t/np.power(P_t,2) #Shape factor to correct


    n = len(A_t)
    t_bool = np.squeeze(np.random.rand(n,1) < prob)
    G = Gcorr_isos(G_t, v_t, prob = t_bool, min_vox = min_vox)
    beta = half_ang_isos(G, prob = t_bool)

    network['throat.shape_factor'] = G
    network['throat.half_cont_angle'] = beta
    network['throat.perimeter'] = (A_t/G)**0.5

    if ('equivalent_diameter' in network['throat'] ) and ('inscribed_diameter' in network['throat'] ):
        #Correct inscribed diameter values
        d_corr = network['throat.inscribed_diameter'] > network['throat.equivalent_diameter']
        network['throat.inscribed_diameter'][d_corr] = network['throat.equivalent_diameter'][d_corr]


    return



