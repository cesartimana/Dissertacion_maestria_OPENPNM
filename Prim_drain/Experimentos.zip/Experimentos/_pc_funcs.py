import logging
import numpy as _np
from openpnm.models import _doctxt
import math as _m

logger = logging.getLogger(__name__)


__all__ = [
    "MSP_prim_drainage",
]


#En las funciones creadas antes, se colocaba en una linea anterior
#lo siguiente: @_doctxt
#Esto lo unico que hace es substituir %(nombre)s por el texto del archivo _doctxt



def MSP_prim_drainage(phase,
	     throat_diameter = 'throat.diameter'):
    r"""
    Computes the capillary entry pressure of all throats

    Parameters
    ----------
    phase: The wetting one
    with the network properties/keys
    throat.surface_tension
    throat.contact_angle
    throat.diameter (the key name can be changed)
    throat.shape_factor


    Returns
    -------
    %(return_arr)s capillary entry pressure

    Notes
    -----
    Reference of the method: Oren 1998 / Valvatne and Blunt 2004

    """
    network = phase.network
    sigma = phase["throat.surface_tension"]
    if phase["throat.contact_angle"].ndim == 1:
          theta = phase["throat.contact_angle"]
    else:
          theta = phase["throat.contact_angle"][:,0]
    theta_r =    _np.tile(theta,(3,1)).T #matrix Nt x 3. All columns are the same
    r = network[throat_diameter] / 2
    G = network["throat.shape_factor"]
    beta = network["throat.half_cont_angle"]
    condition = (beta < (_m.pi / 2 - theta_r))  #just these angles are valid for the addition
    S1 = _np.sum((_np.cos(theta_r) * _np.cos(theta_r + beta) / _np.sin(beta) + theta_r + beta - _m.pi/2) * condition, axis = 1)
    S2 = _np.sum((_np.cos(theta_r + beta) / _np.sin(beta)) * condition, axis = 1)
    S3 = _np.sum((_m.pi / 2 - theta_r - beta) * condition, axis = 1)
    D = S1 - 2 * S2 * _np.cos(theta) + S3
    print(D)
    value = sigma * (1 + _np.sqrt(1 + 4 * G * D / _np.cos(theta)**2)) / r
    value[_np.absolute(value) == _np.inf] = 0 #Is it important??
    return value
