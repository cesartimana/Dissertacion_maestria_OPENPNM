# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 09:41:13 2023

@author: cesar

En este archivo  se calculara todo lo referente a la invasion por Drenaje primario
Se investiga como calcula la presion capilar de entrada  de las gargantas y el proceso de invasion
El algoritmo toma commo referencia el codigo de Invasion_Percolation
El fluido a usar sera el no mojante. El angulo de contacto estará aqui.
El angulo de contacto puede sr un objeto de tamaño Nx1 o Nx2. Siendo N el numero de poros o gargantas
Si es Nx2, la primera fila tiene al menor de los valores y es el receiding contact angle

La presión capilar sera guardada en el objeto de simulacion de drenaje primario porque puede cambiar con el caso.

"""

#Preambulo

import openpnm as op
import porespy as ps
import numpy as np
import imageio as io
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import time
import sys
import math as m
import _algorithm_class as _alg
import _invasion_percolation as _ip

import heapq as hq

np.random.seed(13)


timeZero = time.time()

ws = op.Workspace()

testName_h = 'Network_w_geo.pnm'

proj_h = ws.load_project(filename=testName_h)

pn = proj_h.network

Np = pn.Np
Nt = pn.Nt
print(pn)

#Creating contact angles with two columns
theta = np.ones((Nt,2))
theta[:,0] = 0
theta[:,1] = m.pi/6

if ('equivalent_diameter' in pn['throat'] ) and ('inscribed_diameter' in pn['throat'] ):
        #Correct inscribed diameter values
        d_corr = pn['throat.inscribed_diameter'] > pn['throat.equivalent_diameter']
        pn['throat.inscribed_diameter'][d_corr] = pn['throat.equivalent_diameter'][d_corr]

a = np.sum(pn['throat.equivalent_diameter'] < pn['throat.inscribed_diameter'])
print(a)
print(a/pn.Nt)

#Creating entry pressure
p_ct = np.random.rand(Nt)

#Add phase properties

air = op.phase.Air(network=pn,name='air')
air.add_model_collection(op.models.collections.phase.air)
air.add_model_collection(op.models.collections.physics.basic)
air.regenerate_models()
water = op.phase.Water(network=pn,name='water')
water['pore.surface_tension'] = 0.072
water['throat.surface_tension'] = 0.072
water['throat.contact_angle'] = theta
water.add_model_collection(op.models.collections.phase.water)
water.add_model_collection(op.models.collections.physics.basic)
water.regenerate_models()



#Using the algorithm
pd = _alg.Primary_Drainage(network=pn, phase=water)
#pd =  _ip.InvasionPercolation(network=pn, phase=water)


pd['throat.entry_pressure'] = p_ct
pd.set_inlet_BC(pores=pn['pore.ymax'])
pd.set_outlet_BC(pores=pn['pore.ymin'])
pd._run_setup(throat_diameter = 'throat.inscribed_diameter')

print(pd.settings['phase']) #muestra el nombre de la fase guardada en el algoritmo

#proxima funcion a activar: get_phase
#permite obtener a la fase que es incluida en el algoritmo

#print(pd['throat.entry_pressure'])
#print(pd['throat.sorted'])



#for item in proj_h.phases:
#    print(item.name)


"""
weights = None
if weights is None:
    weights = np.ones((Nt,), dtype=int)

conn = pd.network['throat.conns']
row = conn[:, 0]
row = np.append(row, conn[:, 1])
col = np.arange(Nt)
col = np.append(col, col)
weights = np.append(weights, weights)

import scipy.sparse as sprs
temp = sprs.coo_matrix((weights, (row, col)), (Np, Nt))


temp.tocsr()

print(temp)


"""
